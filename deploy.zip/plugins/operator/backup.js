import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { Operator } from '../../database.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const DB_PATH   = path.join(__dirname, '..', '..', 'data', 'bot_utama.db')

export default (client) => {
  client.command('backup', async (ctx) => {
    if (!Operator.isOp(ctx.from.id)) return ctx.reply('❌ Kamu bukan operator!')

    if (!fs.existsSync(DB_PATH)) {
      return ctx.reply('❌ File database tidak ditemukan!')
    }

    await ctx.replyWithDocument(
      { source: fs.createReadStream(DB_PATH), filename: 'bot_utama.db' },
      {
        caption: `🗄 *Backup DB*\n${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`,
        parse_mode: 'Markdown'
      }
    )
  })
}
