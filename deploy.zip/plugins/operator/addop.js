import { Operator } from '../../database.js'

export default (client) => {
  client.command('addop', async (ctx) => {
    if (!Operator.isOp(ctx.from.id)) return ctx.reply('❌ Kamu bukan operator!')

    const args = ctx.message.text.split(' ').slice(1)
    if (!args[0]) return ctx.reply('Format: /addop <telegram_id>')

    Operator.add(args[0])
    ctx.reply(`✅ ID \`${args[0]}\` berhasil jadi operator!`, { parse_mode: 'Markdown' })
  })

  client.command('delop', async (ctx) => {
    if (!Operator.isOp(ctx.from.id)) return ctx.reply('❌ Kamu bukan operator!')

    const args = ctx.message.text.split(' ').slice(1)
    if (!args[0]) return ctx.reply('Format: /delop <telegram_id>')

    Operator.remove(args[0])
    ctx.reply(`✅ ID \`${args[0]}\` dihapus dari operator!`, { parse_mode: 'Markdown' })
  })
}
