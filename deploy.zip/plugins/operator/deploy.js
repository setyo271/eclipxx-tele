import { Bot as BotDB, Operator } from '../../database.js'
import { spawnChild } from '../../lib/child.js'

export default (client) => {
  client.command('deploy', async (ctx) => {
    if (!Operator.isOp(ctx.from.id)) return ctx.reply('❌ Kamu bukan operator!')

    const args = ctx.message.text.split(' ').slice(1)
    if (args.length < 2) {
      return ctx.reply(
        '❌ Format salah!\n\nGunakan:\n/deploy <token> <telegram_id>',
        { parse_mode: 'Markdown' }
      )
    }

    const [token, ownerId] = args

    if (BotDB.getByToken(token)) {
      return ctx.reply('❌ Token sudah digunakan sebelumnya!')
    }

    if (BotDB.getByOwner(ownerId)) {
      return ctx.reply('❌ ID tersebut sudah pernah trial sebelumnya!')
    }

    try {
      const newBot = BotDB.deploy(token, ownerId)
      spawnChild(newBot)

      await ctx.reply(
        `✅ *Bot berhasil dideploy!*\n\n` +
        `• Owner ID: \`${ownerId}\`\n` +
        `• Trial: 7 hari\n` +
        `• Status: Aktif 🟢`,
        { parse_mode: 'Markdown' }
      )

      // Notif ke owner
      await ctx.api.sendMessage(ownerId,
        `🎉 *Bot kamu berhasil dideploy!*\n\n` +
        `✅ Trial 7 hari dimulai sekarang\n\n` +
        `Buka bot kamu dan ketik /start!`,
        { parse_mode: 'Markdown' }
      ).catch(() => {})

    } catch (err) {
      console.error('[DEPLOY]', err.message)
      ctx.reply('❌ Gagal deploy: ' + err.message)
    }
  })
}
