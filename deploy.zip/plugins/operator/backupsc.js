import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import archiver from 'archiver'
import { Operator } from '../../database.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT      = path.join(__dirname, '..', '..')
const ZIP_PATH  = path.join(ROOT, 'data', 'backup_script.zip')

export default (client) => {
  client.command('backupsc', async (ctx) => {
    if (!Operator.isOp(ctx.from.id)) return ctx.reply('❌ Kamu bukan operator!')

    const msg = await ctx.reply('⏳ Membuat zip script...')

    try {
      await new Promise((resolve, reject) => {
        const output  = fs.createWriteStream(ZIP_PATH)
        const archive = archiver('zip', { zlib: { level: 9 } })

        output.on('close', resolve)
        archive.on('error', reject)
        archive.pipe(output)

        archive.glob('**/*', {
          cwd: ROOT,
          ignore: ['node_modules/**', 'data/**', '*.zip']
        })

        archive.finalize()
      })

      await ctx.api.deleteMessage(ctx.chat.id, msg.message_id)

      await ctx.replyWithDocument(
        { source: fs.createReadStream(ZIP_PATH), filename: 'backup_script.zip' },
        {
          caption: `📦 *Backup Script*\n${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`,
          parse_mode: 'Markdown'
        }
      )

      fs.unlinkSync(ZIP_PATH)

    } catch (err) {
      console.error('[BACKUPSC]', err.message)
      await ctx.api.deleteMessage(ctx.chat.id, msg.message_id).catch(() => {})
      ctx.reply('❌ Gagal buat zip: ' + err.message)
    }
  })
}
