import { db, Operator } from '../../database.js'
import { childCount } from '../../lib/child.js'

export default (client) => {
  client.command('status', async (ctx) => {
    if (!Operator.isOp(ctx.from.id)) return ctx.reply('❌ Kamu bukan operator!')

    const totalBot    = db.prepare('SELECT COUNT(*) as n FROM bots').get().n
    const aktifBot    = db.prepare('SELECT COUNT(*) as n FROM bots WHERE active = 1').get().n
    const totalUser   = db.prepare('SELECT COUNT(*) as n FROM users').get().n
    const totalOp     = db.prepare('SELECT COUNT(*) as n FROM operator').get().n
    const uptime      = Math.floor(process.uptime() / 60)

    ctx.reply(
      `📊 *STATUS BOT UTAMA*\n\n` +
      `• Total Bot Terdaftar : ${totalBot}\n` +
      `• Bot Aktif           : ${aktifBot}\n` +
      `• Bot Running         : ${childCount()}\n` +
      `• Total User          : ${totalUser}\n` +
      `• Total Operator      : ${totalOp}\n` +
      `• Uptime              : ${uptime} menit`,
      { parse_mode: 'Markdown' }
    )
  })
}
