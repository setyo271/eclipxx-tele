export const cmd      = 'ytdl'
export const label    = 'YouTube'
export const endpoint = 'youtube'
