// plugin ini didaftarkan ke child bot lewat lib/child.js
// file ini sengaja kosong karena routing download sudah
// dihandle di lib/child.js → lib/downloader.js
//
// Kalau mau custom logic khusus TikTok, taruh di sini
// lalu import di lib/child.js

export const cmd      = 'ttdl'
export const label    = 'TikTok'
export const endpoint = 'tiktok'
