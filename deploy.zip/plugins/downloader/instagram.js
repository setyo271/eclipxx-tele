export const cmd      = 'igdl'
export const label    = 'Instagram'
export const endpoint = 'instagram'
