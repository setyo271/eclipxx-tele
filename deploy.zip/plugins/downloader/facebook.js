export const cmd      = 'fbdl'
export const label    = 'Facebook'
export const endpoint = 'facebook'
