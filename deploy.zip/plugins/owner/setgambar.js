import { Bot as BotDB } from '../../database.js'
import { restartChild } from '../../lib/child.js'

export default (client) => {
  client.command('setgambar', async (ctx) => {
    const botRow = BotDB.getByOwner(String(ctx.from.id))
    if (!botRow) return ctx.reply('❌ Kamu tidak punya bot yang terdaftar!')

    const args = ctx.message.text.split(' ').slice(1)
    const url  = args[0]?.trim()

    if (!url) {
      return ctx.reply(
        '❌ URL gambar tidak boleh kosong!\n\n' +
        'Format: /setgambar <url_gambar>\n\n' +
        'Contoh:\n/setgambar https://telegra.ph/file/xxx.jpg\n\n' +
        '_Tips: Upload foto ke @telegraph lalu copy link nya_',
        { parse_mode: 'Markdown' }
      )
    }

    if (!url.startsWith('http')) {
      return ctx.reply('❌ URL tidak valid, harus diawali https://')
    }

    BotDB.setStartPhoto(botRow.id, url)
    restartChild({ ...botRow, start_photo: url })

    await ctx.replyWithPhoto(url, {
      caption: '✅ *Gambar /start berhasil diubah!*',
      parse_mode: 'Markdown'
    }).catch(() => {
      ctx.reply('✅ Gambar disimpan, tapi gagal preview. Cek URL nya ya!')
    })
  })
}
