import { Bot as BotDB } from '../../database.js'
import { restartChild } from '../../lib/child.js'

export default (client) => {
  client.command('setstart', async (ctx) => {
    const botRow = BotDB.getByOwner(String(ctx.from.id))
    if (!botRow) return ctx.reply('❌ Kamu tidak punya bot yang terdaftar!')

    const teks = ctx.message.text.split(' ').slice(1).join(' ').trim()

    if (!teks) {
      return ctx.reply(
        '❌ Teks tidak boleh kosong!\n\n' +
        'Format: /setstart <teks pesan>\n\n' +
        'Contoh:\n/setstart Halo! Selamat datang di bot saya 👋'
      )
    }

    BotDB.setStartText(botRow.id, teks)
    restartChild({ ...botRow, start_text: teks })

    ctx.reply(
      `✅ *Teks /start berhasil diubah!*\n\n` +
      `Preview:\n${teks}`,
      { parse_mode: 'Markdown' }
    )
  })
}
