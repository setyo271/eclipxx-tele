import { Bot as BotDB, Operator } from '../../database.js'
import { login, buatInvoice, cekBayar } from '../../lib/saweria.js'
import { restartChild } from '../../lib/child.js'

const HARGA_PER_HARI = 1000

export default (client) => {
  client.command('kuotabot', async (ctx) => {
    const botRow = BotDB.getByOwner(String(ctx.from.id))
    if (!botRow) return ctx.reply('❌ Kamu tidak punya bot yang terdaftar!')

    const args = ctx.message.text.split(' ').slice(1)
    const hari = parseInt(args[0])

    if (!hari || isNaN(hari) || hari < 10) {
      return ctx.reply(
        '❌ Minimal perpanjang 10 hari!\n\n' +
        'Format: /kuotabot <hari>\n' +
        'Contoh: /kuotabot 30\n\n' +
        '💰 Harga: Rp 1.000/hari'
      )
    }

    const total = hari * HARGA_PER_HARI
    const msg   = await ctx.reply('⏳ Membuat invoice...')

    try {
      const userId = await login()
      const trx    = await buatInvoice(userId, total, `Perpanjang Bot ID ${botRow.id} - ${hari} hari`)

      await ctx.api.deleteMessage(ctx.chat.id, msg.message_id)

      const qrBuffer = Buffer.from(
        trx.qr_image.replace(/^data:image\/png;base64,/, ''),
        'base64'
      )

      await ctx.replyWithPhoto(
        { source: qrBuffer },
        {
          caption:
            `💳 *INVOICE PERPANJANGAN*\n\n` +
            `• Durasi : *${hari} hari*\n` +
            `• Total  : *Rp ${total.toLocaleString('id-ID')}*\n` +
            `• Expired: ${trx.expired_at}\n\n` +
            `📲 Scan QR di atas atau buka:\n${trx.receipt}\n\n` +
            `⏳ _Cek otomatis tiap 5 detik (maks 10 menit)_`,
          parse_mode: 'Markdown'
        }
      )

      // Auto cek bayar tiap 5 detik, maks 10 menit
      let attempts = 0
      const maxAttempts = 120

      const interval = setInterval(async () => {
        attempts++

        try {
          const lunas = await cekBayar(userId, trx.id)

          if (lunas) {
            clearInterval(interval)

            BotDB.renew(botRow.id, hari, total)
            const updatedBot = BotDB.getByOwner(String(ctx.from.id))
            restartChild(updatedBot)

            await ctx.reply(
              `✅ *Pembayaran diterima!*\n\n` +
              `• Perpanjang : ${hari} hari\n` +
              `• Bot kamu sudah aktif kembali 🟢\n\n` +
              `Makasih ya! 🎉`,
              { parse_mode: 'Markdown' }
            )

            // Notif semua operator
            const ops = Operator.getAll()
            for (const opId of ops) {
              await ctx.api.sendMessage(
                opId,
                `💰 *PEMBAYARAN MASUK*\n\n` +
                `• Owner ID : \`${ctx.from.id}\`\n` +
                `• Bot ID   : ${botRow.id}\n` +
                `• Durasi   : ${hari} hari\n` +
                `• Nominal  : Rp ${total.toLocaleString('id-ID')}`,
                { parse_mode: 'Markdown' }
              ).catch(() => {})
            }
          }
        } catch (_) {}

        if (attempts >= maxAttempts) {
          clearInterval(interval)
          ctx.reply(
            `⌛ *Waktu pembayaran habis.*\n\n` +
            `Udah bayar? Hubungi operator kami ya!`,
            { parse_mode: 'Markdown' }
          ).catch(() => {})
        }
      }, 5000)

    } catch (err) {
      console.error('[KUOTABOT]', err.message)
      await ctx.api.deleteMessage(ctx.chat.id, msg.message_id).catch(() => {})
      ctx.reply('❌ Gagal buat invoice: ' + err.message)
    }
  })
}
