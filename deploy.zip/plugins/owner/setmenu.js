import { Bot as BotDB } from '../../database.js'
import { restartChild } from '../../lib/child.js'

export default (client) => {
  client.command('setmenu', async (ctx) => {
    const botRow = BotDB.getByOwner(String(ctx.from.id))
    if (!botRow) return ctx.reply('❌ Kamu tidak punya bot yang terdaftar!')

    const args = ctx.message.text.split(' ').slice(1)
    const mode = parseInt(args[0])

    if (![1, 2].includes(mode)) {
      return ctx.reply(
        '❌ Mode tidak valid!\n\n' +
        '/setmenu 1 → menu tampil langsung di /start\n' +
        '/setmenu 2 → menu pakai button kategori'
      )
    }

    BotDB.setMenuMode(botRow.id, mode)
    restartChild({ ...botRow, menu_mode: mode })

    const label = mode === 1 ? 'list (tampil langsung)' : 'button (per kategori)'
    ctx.reply(`✅ Menu diubah ke mode *${label}*`, { parse_mode: 'Markdown' })
  })
}
