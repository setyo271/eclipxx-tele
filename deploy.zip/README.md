# 🤖 TG Bot Utama

## 📁 Struktur
```
tgbot-utama/
├── index.js                        ← entry point
├── client.js                       ← setup bot utama
├── handler.js                      ← auto load plugins
├── database.js                     ← semua query SQLite
│
├── plugins/
│   ├── operator/
│   │   ├── deploy.js               ← /deploy
│   │   ├── backup.js               ← /backup
│   │   ├── backupsc.js             ← /backupsc
│   │   ├── addop.js                ← /addop /delop
│   │   └── status.js               ← /status
│   │
│   ├── owner/
│   │   ├── setmenu.js              ← /setmenu
│   │   ├── setstart.js             ← /setstart
│   │   ├── setgambar.js            ← /setgambar
│   │   └── kuotabot.js             ← /kuotabot + QRIS
│   │
│   └── downloader/
│       ├── tiktok.js               ← config /ttdl
│       ├── youtube.js              ← config /ytdl
│       ├── instagram.js            ← config /igdl
│       └── facebook.js             ← config /fbdl
│
└── lib/
    ├── child.js                    ← spawn/stop/restart child bots
    ├── cron.js                     ← expired check, reset limit, backup
    ├── downloader.js               ← logic download media
    ├── saweria.js                  ← API Saweria (QRIS)
    └── neoxr.js                    ← API NeoxR (download)
```

---

## 🚀 Setup

### 1. Install
```bash
npm install
```

### 2. Buat .env
```bash
cp .env.example .env
nano .env
```
Isi semua variabel yang ada.

### 3. Tambah operator pertama
```bash
node -e "
import('./database.js').then(({ Operator }) => {
  Operator.add('TELEGRAM_ID_KAMU')
  console.log('Done!')
  process.exit()
})
"
```

### 4. Jalankan
```bash
# Development
node index.js

# Production (PM2)
npm install -g pm2
pm2 start index.js --name bot-utama
pm2 save && pm2 startup
```

---

## 📋 Command

| Command | Siapa | Fungsi |
|---------|-------|--------|
| `/deploy <token> <id>` | Operator | Deploy bot child baru |
| `/backup` | Operator | Download file database |
| `/backupsc` | Operator | Download zip script |
| `/addop <id>` | Operator | Tambah operator |
| `/delop <id>` | Operator | Hapus operator |
| `/status` | Operator | Info bot & user |
| `/kuotabot <hari>` | Owner | Perpanjang bot (min 10 hari) |
| `/setmenu 1\|2` | Owner | Atur tampilan menu /start |
| `/setstart <teks>` | Owner | Atur teks /start |
| `/setgambar <url>` | Owner | Atur foto /start |
| `/ytdl /ttdl /igdl /fbdl` | User | Download media |

---

## 💡 Nambah Fitur

- **Fitur owner baru** → buat file di `plugins/owner/namafitur.js`, export default function
- **Fitur operator baru** → buat file di `plugins/operator/namafitur.js`
- **Downloader baru** → tambah endpoint di `lib/neoxr.js` + file di `plugins/downloader/`
- Semua plugin **auto-load**, tidak perlu edit file lain
