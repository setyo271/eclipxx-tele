import { Bot } from 'grammy'
import dotenv from 'dotenv'
dotenv.config()

if (!process.env.BOT_TOKEN) {
  console.error('❌ BOT_TOKEN belum diisi di file .env!')
  process.exit(1)
}

const client = new Bot(process.env.BOT_TOKEN)

export default client
