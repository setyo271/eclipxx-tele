import 'dotenv/config'
import { run } from '@grammyjs/runner'
import client from './client.js'
import { loadPlugins } from './handler.js'
import { spawnAllChilds } from './lib/child.js'
import { startCrons } from './lib/cron.js'

// ─── Load semua plugin bot utama ──────────────────────────
await loadPlugins(client)

// ─── Command /start bot utama ─────────────────────────────
client.command('start', async (ctx) => {
  ctx.reply(
    `👋 *Halo!*\n\n` +
    `Saya adalah Bot Manager.\n\n` +
    `*Operator:*\n` +
    `• /deploy <token> <id> — deploy bot baru\n` +
    `• /backup — download database\n` +
    `• /backupsc — download zip script\n` +
    `• /addop <id> — tambah operator\n` +
    `• /delop <id> — hapus operator\n` +
    `• /status — info bot & user\n\n` +
    `*Owner Bot:*\n` +
    `• /kuotabot <hari> — perpanjang bot\n` +
    `• /setmenu 1|2 — atur tampilan menu\n` +
    `• /setstart <teks> — atur teks /start\n` +
    `• /setgambar <url> — atur foto /start`,
    { parse_mode: 'Markdown' }
  )
})

// ─── Error handler ────────────────────────────────────────
client.catch((err) => {
  console.error('[BOT ERROR]', err.message)
})

// ─── Jalankan bot utama ───────────────────────────────────
run(client)
console.log('[BOT UTAMA] ✅ Running...')

// ─── Spawn semua child bot dari database ─────────────────
spawnAllChilds()

// ─── Jalankan cron jobs ───────────────────────────────────
startCrons()
