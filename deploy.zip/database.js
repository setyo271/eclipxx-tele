import Database from 'better-sqlite3'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const DB_PATH = path.join(__dirname, 'data', 'bot_utama.db')

// ─── Init & buat tabel ────────────────────────────────────
export const db = new Database(DB_PATH)

db.exec(`
  CREATE TABLE IF NOT EXISTS bots (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    token       TEXT    UNIQUE NOT NULL,
    owner_id    TEXT    NOT NULL,
    expired_at  INTEGER NOT NULL,
    active      INTEGER DEFAULT 1,
    menu_mode   INTEGER DEFAULT 1,
    start_text  TEXT    DEFAULT 'Halo saya adalah bot telegram aktif 24 jam non stop',
    start_photo TEXT    DEFAULT '',
    created_at  INTEGER DEFAULT (strftime('%s','now'))
  );

  CREATE TABLE IF NOT EXISTS users (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id TEXT    NOT NULL,
    bot_id      INTEGER NOT NULL,
    lim         INTEGER DEFAULT 10,
    is_premium  INTEGER DEFAULT 0,
    created_at  INTEGER DEFAULT (strftime('%s','now')),
    UNIQUE(telegram_id, bot_id)
  );

  CREATE TABLE IF NOT EXISTS operator (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id TEXT    UNIQUE NOT NULL
  );

  CREATE TABLE IF NOT EXISTS payments (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    bot_id  INTEGER NOT NULL,
    amount  INTEGER NOT NULL,
    days    INTEGER NOT NULL,
    paid_at INTEGER DEFAULT (strftime('%s','now'))
  );
`)

// ─── BOTS ─────────────────────────────────────────────────
export const Bot = {
  getByToken:   (token)   => db.prepare('SELECT * FROM bots WHERE token = ?').get(token),
  getByOwner:   (ownerId) => db.prepare('SELECT * FROM bots WHERE owner_id = ?').get(ownerId),
  getById:      (id)      => db.prepare('SELECT * FROM bots WHERE id = ?').get(id),
  getAllActive:  ()        => db.prepare('SELECT * FROM bots WHERE active = 1').all(),

  deploy(token, ownerId) {
    const expiredAt = Math.floor(Date.now() / 1000) + 7 * 86400
    db.prepare('INSERT INTO bots (token, owner_id, expired_at) VALUES (?, ?, ?)').run(token, ownerId, expiredAt)
    return this.getByToken(token)
  },

  renew(botId, days, amount) {
    const bot = this.getById(botId)
    const now = Math.floor(Date.now() / 1000)
    const base = bot.expired_at > now ? bot.expired_at : now
    db.prepare('UPDATE bots SET expired_at = ?, active = 1 WHERE id = ?').run(base + days * 86400, botId)
    db.prepare('INSERT INTO payments (bot_id, amount, days) VALUES (?, ?, ?)').run(botId, amount, days)
  },

  deactivate: (botId) => db.prepare('UPDATE bots SET active = 0 WHERE id = ?').run(botId),
  setMenuMode: (botId, mode) => db.prepare('UPDATE bots SET menu_mode = ? WHERE id = ?').run(mode, botId),
  setStartText: (botId, text) => db.prepare('UPDATE bots SET start_text = ? WHERE id = ?').run(text, botId),
  setStartPhoto: (botId, url) => db.prepare('UPDATE bots SET start_photo = ? WHERE id = ?').run(url, botId),
}

// ─── USERS ────────────────────────────────────────────────
export const User = {
  get(telegramId, botId) {
    let user = db.prepare('SELECT * FROM users WHERE telegram_id = ? AND bot_id = ?').get(telegramId, botId)
    if (!user) {
      db.prepare('INSERT OR IGNORE INTO users (telegram_id, bot_id) VALUES (?, ?)').run(telegramId, botId)
      user = db.prepare('SELECT * FROM users WHERE telegram_id = ? AND bot_id = ?').get(telegramId, botId)
    }
    return user
  },

  decrementLimit: (telegramId, botId) =>
    db.prepare('UPDATE users SET lim = lim - 1 WHERE telegram_id = ? AND bot_id = ? AND lim > 0').run(telegramId, botId),

  resetAllLimits: () =>
    db.prepare('UPDATE users SET lim = CASE WHEN is_premium = 1 THEN 1000 ELSE 10 END').run(),
}

// ─── OPERATOR ─────────────────────────────────────────────
export const Operator = {
  getAll:  ()  => db.prepare('SELECT telegram_id FROM operator').all().map(r => r.telegram_id),
  isOp:    (id) => !!db.prepare('SELECT 1 FROM operator WHERE telegram_id = ?').get(String(id)),
  add:     (id) => db.prepare('INSERT OR IGNORE INTO operator (telegram_id) VALUES (?)').run(String(id)),
  remove:  (id) => db.prepare('DELETE FROM operator WHERE telegram_id = ?').run(String(id)),
}
