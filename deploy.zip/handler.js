import { readdirSync } from 'fs'
import path from 'path'
import { fileURLToPath, pathToFileURL } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

export async function loadPlugins(client) {
  const categories = ['operator', 'owner', 'downloader']

  for (const category of categories) {
    const dir = path.join(__dirname, 'plugins', category)
    const files = readdirSync(dir).filter(f => f.endsWith('.js'))

    for (const file of files) {
      const filePath = pathToFileURL(path.join(dir, file)).href
      const plugin = await import(filePath)

      if (typeof plugin.default === 'function') {
        plugin.default(client)
        console.log(`[PLUGIN] ✅ ${category}/${file}`)
      } else {
        console.warn(`[PLUGIN] ⚠️  ${category}/${file} tidak export default function`)
      }
    }
  }
}
